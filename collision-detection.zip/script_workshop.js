"use strict";

var vp_width = window.innerWidth/2; //create and assign a variable variable to hold the screen size
var vp_height = window.innerHeight/2;

var x = vp_width/2; //create and assign a variable to hold an position that is half of the viewport
var y = vp_height/2;

var colour = "ff0000";

var r1 ={x:50,y:5,w:50,h:50};
var r2 = {x:120, y:10, w:10,h:10};

// var c1 = {radius: 20, x:5, y:5};
// var c2 = {radius: 12, x:10, y:5};
// var dx = c1.x - c






function set_vp() {
	vp_width = window.innerWidth/2;
	vp_height = window.innerHeight/2;

	x = vp_width/2; //update the ball's initial position
	y = vp_height/2;

	resizeCanvas(vp_width, vp_height); //call the P5 resize canvas function; is this abstraction?
}

function up(){
    
    r2.y = r2.y - 5;
}

function down(){
    
    r2.y = r2.y + 5;
}

function left(){
    
    r2.x = r2.x - 5;
}

function right(){
    
    r2.x = r2.x + 5;
}


function preload() {
	//p5 defined function
}

function setup() {
	//this p5 defined function runs automatically once the preload function is done
	
	var viewport = createCanvas(vp_width, vp_height);
    viewport.parent("viewport_container"); //move the canvas so it’s inside the target div

    frameRate(50);
}

function paint_background() {
	//this function fills the canvas background with the specific colour
	background("#abb5b9");
}

function paint_player() {
	fill("#" + colour); //set a fill colour using the variable
	circle(x, y, 20); //draw a circle and x, y with a diameter of 20

}

function paint_rectangle() {
	fill("#" + colour); //set a fill colour using the variable
	rect(r1.x, r1.y, r1.w,r1.h); //draw a circle and x, y with a diameter of 20
  rect(r2.x, r2.y, r2.w,r2.h);
}

function draw() {
	 //this p5 defined function runs every refresh cycle
	 paint_background();
	 paint_player();
   paint_rectangle();
   if(r1.x <(r2.x + r2.w) && (r1.x + r1.w) > r2.x && r1.y < (r2.y +r2.h) && (r1.y +r1.h) > r2.y ){
    console.log("collision")
  }
}


//create events for the number buttons
var buttons = document.getElementsByTagName('button');
for(let i = 0; i < buttons.length; i++) { //loop through each specific instance of number buttons
	buttons[i].addEventListener('click', function() {
        
        switch(this.id) {
            case "up": up(); break;
            case "down": down(); break;
            case "left": left(); break;
            case "right": right(); break;
        }

	})
}

window.addEventListener('resize', set_vp);
